# Security Specification (TDD) for Firebase

As application safety is paramount, we define the data invariants, vulnerable payloads, and rule structures to protect our user watchlist data and global user reviews.

## 1. Data Invariants

1. **User Identity Isolation**: A user's profile under `/users/{userId}` and their subcollection `/users/{userId}/watchlist/{animeId}` can only be read or written by the authenticated owner (`request.auth.uid == userId`).
2. **Review Integrity**: Any user can read standard reviews under `/anime_reviews/{reviewId}`. However, creating or updating can only be done by a verified user (`request.auth.token.email_verified == true`) whose payload contains their genuine `userId`.
3. **Immutable Ownership**: Once a review or watchlist item is created, its ownership (`userId`/`ownerId`) cannot be altered or hijacked during an update.
4. **Data Type and Range Constraints**: 
   - Ratings (`score`) must be integers or floating-point numbers between `1` and `10` inclusive.
   - Text fields like `reviewText` must have strict size bounds to prevent resource exhaustion and visual spam.
   - Timestamp properties (`createdAt`, `updatedAt`) must be strictly constrained to `request.time` (no client timestamps).

---

## 2. The "Dirty Dozen" Hostile Payloads

These payloads must always be rejected by the rules with `PERMISSION_DENIED`:

### Hijacking / Identity Spoofing
1. **P1: Cross-User Profile Write**: Authenticated user `A` tries to write to `/users/B`.
2. **P2: Cross-User Watchlist Add**: Authenticated user `A` tries to add a watch item to `/users/B/watchlist/123`.
3. **P3: Review Identity Spoofing**: Signed-in user `A` (UID `uid_A`) submits a review to `/anime_reviews/r1` with `"userId": "uid_B"`.

### Schema and Type Poisoning
4. **P4: Out-Of-Bounds Rating**: Submitting a review with a score of `999` or `-5`.
5. **P5: Missing Required Key**: Submitting a watchlist item without `"title"`.
6. **P6: Gigantic String Payload**: Injecting a 2MB string in the `"reviewText"` field to cause denial-of-wallet resource depletion.
7. **P7: Malformed Document ID**: Inserting control characters or SQL-like injection strings in path variables (e.g., trying to write to `/anime_reviews/..%2fabc`).
8. **P8: Fake Verification Flag**: Submitting a profile where `"email_verified"` is set to `"true"` on client-side properties (RBAC injection).

### State / Temporal Integrity Hacks
9. **P9: Client-Side Timestamp Manipulation**: Creating a review with a hardcoded, fake `"createdAt"` timestamp (e.g., set to 10 years in the future) rather than `request.time`.
10. **P10: Review Ownership Update Mutation**: Modifying or updating another user's review to transfer its ownership.
11. **P12: Rogue Update Fields**: Modifying immutable review metadata (e.g. `animeId` or `userId` change) through an update block.
12. **P12: Orphaned Child Reference**: Attempting to create a review with an invalid, non-supported document target.

---

## 3. Rule Structure Verification (Concept)

All tests will run against our local Jest/Emulators setup or rules engine to guarantee that these test cases fail securely and that any valid transactions succeed.
