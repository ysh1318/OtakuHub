import React, { useState, useEffect } from "react";
import { Icon } from "./Icons";
import { playSound } from "../utils/audio";

interface SponsorAdProps {
  format?: "banner" | "leaderboard" | "square" | "native";
  className?: string;
}

// Simulated active campaign designs
interface AdCampaign {
  id: string;
  title: string;
  sponsor: string;
  desc: string;
  cta: string;
  url: string;
  gradient: string;
  accent: string;
  visualEmoji: string;
}

const SPONSOR_CAMPAIGNS: AdCampaign[] = [
  {
    id: "crunchyroll",
    title: "Start Your Free Trial Now",
    sponsor: "Crunchyroll Premium",
    desc: "Stream thousands of anime episodes ad-free and hot off the press, straight from Japan!",
    cta: "Get 14 Days Free",
    url: "https://www.crunchyroll.com",
    gradient: "linear-gradient(135deg, #f47521, #b53805)",
    accent: "#f47521",
    visualEmoji: "🟠",
  },
  {
    id: "goodsmile",
    title: "Limited Edition Figure Pre-orders",
    sponsor: "Good Smile Company",
    desc: "Aesthetic scale figurines & customizable Nendoroids of your favorite characters. Shop official.",
    cta: "Pre-order Now",
    url: "https://www.goodsmile.info",
    gradient: "linear-gradient(135deg, #4f46e5, #0ea5e9)",
    accent: "#38bdf8",
    visualEmoji: "🌟",
  },
  {
    id: "secretlab",
    title: "Signature Anime Chair Editions",
    sponsor: "Secretlab",
    desc: "Experience ultimate award-winning comfort. Backed by science, designed for Otaku long-play.",
    cta: "Explore Lineup",
    url: "https://secretlab.co",
    gradient: "linear-gradient(135deg, #1e1b4b, #4338ca)",
    accent: "#818cf8",
    visualEmoji: "💺",
  },
  {
    id: "youtooz",
    title: "Collectible Vinyl Art Figures",
    sponsor: "Youtooz Collectibles",
    desc: "Epic custom anime vinyl figures representing top-tier creators, memes, and pop-culture icons.",
    cta: "Claim Yours",
    url: "https://youtooz.com",
    gradient: "linear-gradient(135deg, #db2777, #9d174d)",
    accent: "#f472b6",
    visualEmoji: "✨",
  },
];

// Custom Hook to check for Premium account status or Ads Opt-out configuration
export function useAdVisibility() {
  const [showAds, setShowAds] = useState(true);

  useEffect(() => {
    const checkState = () => {
      const premium = localStorage.getItem("user_is_premium") === "true";
      const optOut = localStorage.getItem("ad_opt_out") === "true";
      // If user is premium OR user has opted out, hide the advertisement campaigns
      setShowAds(!premium && !optOut);
    };

    checkState();

    window.addEventListener("settings_changed", checkState);
    window.addEventListener("admob_changed", checkState);
    return () => {
      window.removeEventListener("settings_changed", checkState);
      window.removeEventListener("admob_changed", checkState);
    };
  }, []);

  return showAds;
}

export const SponsorAd: React.FC<SponsorAdProps> = ({ format = "banner", className = "" }) => {
  const showAds = useAdVisibility();
  const [appId, setAppId] = useState("ca-app-pub-2489206133174145~6314022285");
  const [adUnitId, setAdUnitId] = useState("ca-app-pub-2489206133174145/2150204540");
  const [showInspector, setShowInspector] = useState(false);
  const [copiedId, setCopiedId] = useState<"app" | "unit" | null>(null);
  const [currentCampaign, setCurrentCampaign] = useState<AdCampaign>(SPONSOR_CAMPAIGNS[0]);
  const [impressions, setImpressions] = useState(0);
  const [clicks, setClicks] = useState(0);
  const [revenue, setRevenue] = useState(0);
  const [isEditing, setIsEditing] = useState(false);
  const [editAppId, setEditAppId] = useState("");
  const [editAdUnitId, setEditAdUnitId] = useState("");

  // Load and save from LocalStorage
  useEffect(() => {
    const savedAppId = localStorage.getItem("admob_app_id");
    const savedAdUnitId = localStorage.getItem("admob_ad_unit_id");
    if (savedAppId) setAppId(savedAppId);
    if (savedAdUnitId) setAdUnitId(savedAdUnitId);

    const savedImpressions = localStorage.getItem("admob_sim_impressions") || "0";
    const savedClicks = localStorage.getItem("admob_sim_clicks") || "0";
    const savedRevenue = localStorage.getItem("admob_sim_revenue") || "0.00";

    setImpressions(parseInt(savedImpressions, 10) + 1);
    localStorage.setItem("admob_sim_impressions", (parseInt(savedImpressions, 10) + 1).toString());

    setClicks(parseInt(savedClicks, 10));
    setRevenue(parseFloat(savedRevenue));

    // Choose a random campaign
    const rand = SPONSOR_CAMPAIGNS[Math.floor(Math.random() * SPONSOR_CAMPAIGNS.length)];
    setCurrentCampaign(rand);
  }, []);

  // Listen for dynamic changes in credentials
  useEffect(() => {
    const handleChanged = () => {
      const savedAppId = localStorage.getItem("admob_app_id");
      const savedAdUnitId = localStorage.getItem("admob_ad_unit_id");
      if (savedAppId) setAppId(savedAppId);
      if (savedAdUnitId) setAdUnitId(savedAdUnitId);
    };
    window.addEventListener("admob_changed", handleChanged);
    return () => window.removeEventListener("admob_changed", handleChanged);
  }, []);

  // Clean-up or do not render if ads are disabled (placed after all hooks)
  if (!showAds) {
    return null;
  }

  const triggerClick = () => {
    playSound("click");
    const nextClicks = clicks + 1;
    // Mocking an RPM of $4.50 (clicks * simulated payout)
    const nextRevenue = parseFloat((revenue + parseFloat((Math.random() * 0.45 + 0.12).toFixed(4))).toFixed(4));

    setClicks(nextClicks);
    setRevenue(nextRevenue);

    localStorage.setItem("admob_sim_clicks", nextClicks.toString());
    localStorage.setItem("admob_sim_revenue", nextRevenue.toString());

    window.open(currentCampaign.url, "_blank");
  };

  const handleCopy = (text: string, type: "app" | "unit") => {
    playSound("success");
    navigator.clipboard.writeText(text);
    setCopiedId(type);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSaveSettings = () => {
    playSound("success");
    setAppId(editAppId);
    setAdUnitId(editAdUnitId);
    localStorage.setItem("admob_app_id", editAppId);
    localStorage.setItem("admob_ad_unit_id", editAdUnitId);
    setIsEditing(false);
  };

  const startEditing = () => {
    playSound("click");
    setEditAppId(appId);
    setEditAdUnitId(adUnitId);
    setIsEditing(true);
  };

  const resetStats = () => {
    playSound("click");
    setImpressions(1);
    setClicks(0);
    setRevenue(0.0);
    localStorage.setItem("admob_sim_impressions", "1");
    localStorage.setItem("admob_sim_clicks", "0");
    localStorage.setItem("admob_sim_revenue", "0.00");
  };

  // Styled components based on format selected
  if (format === "leaderboard") {
    return (
      <div className={`w-full max-w-4xl mx-auto my-4 transition-all ${className}`} id="admob-leaderboard-container">
        {/* Main Ad Banner Bar */}
        <div 
          onClick={triggerClick}
          className="relative overflow-hidden rounded-xl border border-white/5 bg-slate-950 p-[1px] cursor-pointer group hover:border-indigo-500/20 shadow-2xl transition duration-300"
          style={{ minHeight: "90px" }}
        >
          {/* Subtle Ambient Hover Outline */}
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-out" />
          
          <div className="flex flex-col sm:flex-row items-center justify-between p-4 bg-slate-950/90 rounded-[11px] h-full gap-4">
            <div className="flex items-center gap-4">
              <div 
                className="w-12 h-12 rounded-lg flex items-center justify-center text-xl shrink-0"
                style={{ background: currentCampaign.gradient }}
              >
                {currentCampaign.visualEmoji}
              </div>
              <div className="text-left">
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-extrabold px-1.5 py-0.5 rounded uppercase tracking-wider text-slate-300 bg-white/10 text-xs">SPONSORED</span>
                  <span className="text-xs font-bold text-slate-400">{currentCampaign.sponsor}</span>
                </div>
                <h4 className="text-sm font-black text-white mt-1 group-hover:text-indigo-400 transition-colors">{currentCampaign.title}</h4>
                <p className="text-xs text-slate-400 hidden md:block mt-0.5 max-w-lg truncate">{currentCampaign.desc}</p>
              </div>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  playSound("click");
                  setShowInspector(!showInspector);
                }}
                className="p-1 px-2.5 rounded bg-white/5 border border-white/10 hover:bg-white/10 text-slate-400 hover:text-white transition text-[10px] uppercase font-bold flex items-center gap-1.5"
                title="Inspect AdMob SDK Credentials"
              >
                <Icon name="shield" size={10} />
                <span>AdMob ID Check</span>
              </button>
              
              <div className="px-4 py-2 rounded-lg bg-indigo-500 text-white font-black text-xs hover:bg-indigo-600 shadow-md group-hover:scale-105 transition duration-200">
                {currentCampaign.cta}
              </div>
            </div>
          </div>
        </div>

        {/* Dynamic Inner AdMob SDK Inspector Widget */}
        {showInspector && (
          <div className="mt-2 text-left bg-slate-900/90 border border-indigo-500/20 rounded-xl p-4 text-xs shadow-xl animate-fadeIn">
            <div className="flex items-center justify-between mb-3 pb-2 border-b border-white/5">
              <div className="flex items-center gap-2 text-slate-300 font-bold">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span>Simulated AdMob SDK Unit Status</span>
              </div>
              <div className="flex gap-2">
                <button onClick={startEditing} className="text-[10px] text-indigo-400 hover:underline">Edit IDs</button>
                <button onClick={resetStats} className="text-[10px] text-rose-400 hover:underline">Reset CTR</button>
              </div>
            </div>

            {isEditing ? (
              <div className="space-y-3 bg-black/30 p-3 rounded-lg border border-white/5 mb-3">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] text-slate-400 font-bold uppercase mb-1">AdMob App ID</label>
                    <input 
                      type="text" 
                      value={editAppId} 
                      onChange={(e) => setEditAppId(e.target.value)} 
                      className="w-full bg-slate-800 text-white border border-white/10 rounded px-2 py-1 text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-400 font-bold uppercase mb-1">AdMob Ad Unit ID</label>
                    <input 
                      type="text" 
                      value={editAdUnitId} 
                      onChange={(e) => setEditAdUnitId(e.target.value)} 
                      className="w-full bg-slate-800 text-white border border-white/10 rounded px-2 py-1 text-xs"
                    />
                  </div>
                </div>
                <div className="flex justify-end gap-2 text-[11px]">
                  <button onClick={() => setIsEditing(false)} className="px-2 py-1 bg-white/5 hover:bg-white/10 rounded text-slate-300">Cancel</button>
                  <button onClick={handleSaveSettings} className="px-2 py-1 bg-indigo-500 hover:bg-indigo-600 text-white rounded font-bold">Save Changes</button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
                <div className="bg-black/30 p-2.5 rounded-lg border border-white/5 flex items-center justify-between">
                  <div className="truncate pr-2">
                    <span className="block text-[9px] text-slate-500 font-bold tracking-wider">APP ID</span>
                    <code className="text-[11px] text-slate-300 font-mono">{appId}</code>
                  </div>
                  <button 
                    onClick={() => handleCopy(appId, "app")} 
                    className="p-1 px-2 shrink-0 rounded bg-white/5 hover:bg-indigo-400/20 hover:text-indigo-300 transition text-[10px]"
                  >
                    {copiedId === "app" ? "COPIED" : "COPY"}
                  </button>
                </div>

                <div className="bg-black/30 p-2.5 rounded-lg border border-white/5 flex items-center justify-between">
                  <div className="truncate pr-2">
                    <span className="block text-[9px] text-slate-500 font-bold tracking-wider">AD UNIT ID (BANNER)</span>
                    <code className="text-[11px] text-slate-300 font-mono">{adUnitId}</code>
                  </div>
                  <button 
                    onClick={() => handleCopy(adUnitId, "unit")} 
                    className="p-1 px-2 shrink-0 rounded bg-white/5 hover:bg-indigo-400/20 hover:text-indigo-300 transition text-[10px]"
                  >
                    {copiedId === "unit" ? "COPIED" : "COPY"}
                  </button>
                </div>
              </div>
            )}

            {/* Simulated Live Analytics dashboard */}
            <div className="grid grid-cols-3 gap-2 bg-black/25 p-2 rounded-lg border border-white/5 text-[11px] text-slate-400">
              <div className="text-center">
                <span className="block text-[9px] text-slate-500">Impressions</span>
                <span className="font-mono font-bold text-slate-200">{impressions}</span>
              </div>
              <div className="text-center border-l border-white/5">
                <span className="block text-[9px] text-slate-500">Simulator Clicks</span>
                <span className="font-mono font-bold text-emerald-400">{clicks}</span>
              </div>
              <div className="text-center border-l border-white/5">
                <span className="block text-[9px] text-slate-500">Est. Match Earnings API</span>
                <span className="font-mono font-bold text-indigo-400">${revenue.toFixed(2)} USD</span>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // Render format === "native" or "square" bento-style box
  return (
    <div 
      className={`relative w-full overflow-hidden rounded-xl border border-white/5 bg-slate-950 p-[1px] cursor-pointer group hover:border-indigo-500/25 shadow-xl transition duration-300 ${className}`}
      onClick={triggerClick}
      id="admob-native-container"
    >
      <div className="p-4 bg-slate-950/90 rounded-[11px] text-left">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-1.5">
            <span className="text-[9px] font-extrabold px-1.5 py-0.5 rounded uppercase tracking-wider text-slate-300 bg-white/10">AD</span>
            <span className="text-[10px] font-bold text-slate-400 truncate max-w-[120px]">{currentCampaign.sponsor}</span>
          </div>
          <button 
            onClick={(e) => {
              e.stopPropagation();
              playSound("click");
              setShowInspector(!showInspector);
            }}
            className="p-1 rounded bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition"
            title="Inspect AdMob Credentials"
          >
            <Icon name="shield" size={10} />
          </button>
        </div>

        <div className="flex gap-3 mb-3">
          <div 
            className="w-10 h-10 rounded-lg flex items-center justify-center text-lg shrink-0"
            style={{ background: currentCampaign.gradient }}
          >
            {currentCampaign.visualEmoji}
          </div>
          <div>
            <h4 className="text-xs font-black text-white group-hover:text-indigo-400 transition-colors line-clamp-1">{currentCampaign.title}</h4>
            <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-2 leading-relaxed">{currentCampaign.desc}</p>
          </div>
        </div>

        <div className="flex items-center justify-between mt-1">
          <span className="text-[9px] text-indigo-400/80 font-bold uppercase tracking-wider group-hover:text-indigo-300">
            {currentCampaign.cta} ➜
          </span>
          <span className="text-[9px] font-mono text-slate-500">{impressions} views</span>
        </div>

        {/* Compact Inspector */}
        {showInspector && (
          <div className="mt-3 pt-3 border-t border-white/5 text-[10px] text-slate-500 space-y-2 animate-fadeIn" onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-between items-center text-[9px] font-bold text-slate-400 uppercase">
              <span>AdMob SDK Details</span>
              <button onClick={resetStats} className="text-rose-400 hover:underline">Reset</button>
            </div>
            
            <div className="bg-black/40 p-1.5 rounded space-y-1 font-mono text-[9px] text-slate-400">
              <div className="flex justify-between">
                <span>App ID:</span>
                <span className="text-slate-300 truncate max-w-[150px]">{appId}</span>
              </div>
              <div className="flex justify-between">
                <span>Unit ID:</span>
                <span className="text-slate-300 truncate max-w-[150px]">{adUnitId}</span>
              </div>
            </div>

            <div className="flex justify-between text-[9px] text-slate-400">
              <span>Simulation Clicks: <span className="font-bold text-emerald-400">{clicks}</span></span>
              <span>Matched Revenue: <span className="font-bold text-indigo-400">${revenue.toFixed(2)}</span></span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
