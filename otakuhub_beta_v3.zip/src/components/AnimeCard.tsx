import React, { useState, useEffect, useRef } from "react";
import { motion } from "motion/react";
import { Anime } from "../types";
import { Icon } from "./Icons";
import { CardSkeleton, Stars } from "./CommonUI";
import { playSound } from "../utils/audio";

interface AnimeCardProps {
  anime: Anime;
  onClick: (anime: Anime) => void;
  badge?: string | null;
  epBadge?: string | null;
  delay?: number;
  watchlist?: Anime[] | null;
  toggleWatchlist?: ((anime: Anime) => void) | null;
  ecchi?: boolean;
}

export const AnimeCard: React.FC<AnimeCardProps> = ({
  anime,
  onClick,
  badge = null,
  epBadge = null,
  delay: animDelay = 0,
  watchlist = null,
  toggleWatchlist = null,
  ecchi = false,
}) => {
  const [hov, setHov] = useState(false);
  const [imgLoaded, setImgLoaded] = useState(false);
  const [rotateX, setRotateX] = useState(0);
  const [rotateY, setRotateY] = useState(0);
  const [glowX, setGlowX] = useState(50);
  const [glowY, setGlowY] = useState(50);
  const [isDesktop, setIsDesktop] = useState(false);

  useEffect(() => {
    setIsDesktop(window.innerWidth >= 768);
    const handleResize = () => {
      setIsDesktop(window.innerWidth >= 768);
    };
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  if (!anime) return <CardSkeleton />;
  const img = anime.images?.jpg?.large_image_url || anime.images?.jpg?.image_url;
  const score = anime.score;
  const inWL = watchlist ? watchlist.some((w) => w.mal_id === anime.mal_id) : false;
  const hoverClass = ecchi ? "ecchi-card-hover" : "card-hover";

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    // Normalize cursor coordinates from -8deg to +8deg tilt bounds
    const rY = ((mouseX / width) - 0.5) * 16;
    const rX = -((mouseY / height) - 0.5) * 16;

    setRotateX(rX);
    setRotateY(rY);
    setGlowX((mouseX / width) * 100);
    setGlowY((mouseY / height) * 100);
  };

  const handleMouseEnter = () => {
    setHov(true);
    playSound("hover");
  };

  const handleMouseLeave = () => {
    setHov(false);
    setRotateX(0);
    setRotateY(0);
  };

  return (
    <motion.div
      className={hoverClass}
      onClick={() => {
        playSound("click");
        onClick(anime);
      }}
      animate={{
        scale: hov && isDesktop ? 1.08 : 1,
        y: hov && isDesktop ? -6 : 0,
        rotateX: hov && isDesktop ? rotateX : 0,
        rotateY: hov && isDesktop ? rotateY : 0,
        boxShadow: hov
          ? isDesktop
            ? ecchi
              ? "0 24px 44px rgba(0, 0, 0, 0.75), 0 0 35px rgba(236, 72, 153, 0.45)"
              : "0 24px 44px rgba(0, 0, 0, 0.75), 0 0 35px rgba(99, 102, 241, 0.35)"
            : ecchi
              ? "0 16px 32px rgba(0, 0, 0, 0.55), 0 0 15px rgba(236,72,153,0.2)"
              : "0 16px 32px rgba(0, 0, 0, 0.55), 0 0 15px rgba(99,102,241,0.15)"
          : hov
            ? ecchi
              ? "0 24px 44px rgba(0, 0, 0, 0.65), 0 0 25px rgba(236,72,153,0.3)"
              : "0 24px 44px rgba(0, 0, 0, 0.65), 0 0 25px rgba(99,102,241,0.2)"
            : "0 4px 12px rgba(0, 0, 0, 0.4)",
        borderColor: hov && isDesktop
          ? ecchi ? "rgba(236, 72, 153, 0.5)" : "rgba(99, 102, 241, 0.55)"
          : "rgba(255, 255, 255, 0.04)",
      }}
      transition={
        hov
          ? { type: "spring", stiffness: 350, damping: 25, mass: 0.6 }
          : { type: "spring", stiffness: 220, damping: 28, mass: 1 }
      }
      style={{
        cursor: "pointer",
        position: "relative",
        borderRadius: "10px",
        overflow: "hidden",
        aspectRatio: "2/3",
        background: "#0f0f1a",
        flexShrink: 0,
        animation: animDelay >= 0 ? `cardReveal 0.4s ${animDelay}ms ease forwards` : "none",
        opacity: animDelay >= 0 ? 0 : 1,
        transformStyle: "preserve-3d",
        perspective: "1000px",
        border: "1px solid rgba(255, 255, 255, 0.04)",
      }}
      onMouseMove={handleMouseMove}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      {/* Specular dynamic reflection overlay */}
      <motion.div
        animate={{
          opacity: hov ? 1 : 0,
          background: `radial-gradient(circle at ${glowX}% ${glowY}%, rgba(255,255,255,${isDesktop ? 0.22 : 0.14}) 0%, transparent 60%)`,
        }}
        transition={{ duration: 0.3 }}
        style={{
          position: "absolute",
          inset: 0,
          zIndex: 4,
          pointerEvents: "none",
          mixBlendMode: "overlay",
        }}
      />

      {!imgLoaded && (
        <div
          style={{
            width: "100%",
            height: "100%",
            background: "linear-gradient(90deg, #0f0f1a 25%, #1a1a2e 50%, #0f0f1a 75%)",
            backgroundSize: "200% 100%",
            animation: "shimmer 1.5s infinite",
          }}
        />
      )}
      {img && (
        <motion.img
          src={img}
          alt={anime.title}
          animate={{
            scale: hov && isDesktop ? 1.06 : 1,
          }}
          transition={{ duration: 0.4, ease: "easeOut" }}
          style={{
            width: "100%",
            height: "100%",
            objectFit: "cover",
            display: imgLoaded ? "block" : "none",
          }}
          onLoad={() => setImgLoaded(true)}
        />
      )}
      {badge && (
        <span
          style={{
            position: "absolute",
            top: "8px",
            left: "8px",
            background:
              badge === "NEW"
                ? "#10b981"
                : ecchi
                  ? "linear-gradient(90deg,#ec4899,#f43f5e)"
                  : "#6366f1",
            color: "#fff",
            fontSize: "9px",
            fontWeight: 800,
            padding: "2px 7px",
            borderRadius: "4px",
            letterSpacing: "0.8px",
            textTransform: "uppercase",
            zIndex: 5,
          }}
        >
          {badge}
        </span>
      )}
      {epBadge && (
        <span
          style={{
            position: "absolute",
            top: "8px",
            left: "8px",
            background: "rgba(0,0,0,0.78)",
            backdropFilter: "blur(4px)",
            color: "#e2e8f0",
            fontSize: "9px",
            fontWeight: 700,
            padding: "2px 7px",
            borderRadius: "4px",
            zIndex: 5,
          }}
        >
          {epBadge}
        </span>
      )}
      {toggleWatchlist && hov && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            toggleWatchlist(anime);
          }}
          style={{
            position: "absolute",
            top: "8px",
            right: "8px",
            width: "26px",
            height: "26px",
            borderRadius: "7px",
            background: inWL
              ? ecchi
                ? "rgba(236,72,153,0.9)"
                : "rgba(99,102,241,0.9)"
              : "rgba(0,0,0,0.75)",
            backdropFilter: "blur(8px)",
            border: `1px solid ${inWL ? (ecchi ? "#ec4899" : "#6366f1") : "rgba(255,255,255,0.2)"}`,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            cursor: "pointer",
            transition: "all 0.15s",
            zIndex: 10,
          }}
        >
          <Icon name={inWL ? "check" : "plus"} size={12} color={inWL ? "#fff" : "#e2e8f0"} />
        </button>
      )}
      <div
        style={{
          position: "absolute",
          inset: 0,
          background: ecchi
            ? "linear-gradient(transparent 38%, rgba(20,0,15,0.94) 100%)"
            : "linear-gradient(transparent 40%, rgba(0,0,0,0.92) 100%)",
          opacity: hov ? 1 : 0.8,
          transition: "opacity 0.3s",
          zIndex: 2,
        }}
      />
      <motion.div
        animate={{
          y: hov && isDesktop ? 0 : 2,
        }}
        transition={{ duration: 0.3 }}
        style={{
          position: "absolute",
          bottom: 0,
          left: 0,
          right: 0,
          padding: "24px 9px 9px",
          zIndex: 5,
        }}
      >
        <p
          style={{
            fontSize: "11px",
            fontWeight: 700,
            color: "#fff",
            lineHeight: 1.3,
            marginBottom: "4px",
            overflow: "hidden",
            display: "-webkit-box",
            WebkitLineClamp: 2,
            WebkitBoxOrient: "vertical",
          }}
        >
          {anime.title}
        </p>
        <div style={{ display: "flex", alignItems: "center", gap: "5px" }}>
          {score && (
            <>
              <svg
                width="9"
                height="9"
                viewBox="0 0 24 24"
                fill={ecchi ? "#f472b6" : "#f59e0b"}
                stroke={ecchi ? "#f472b6" : "#f59e0b"}
                strokeWidth="1.5"
              >
                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
              </svg>
              <span style={{ fontSize: "10px", color: ecchi ? "#f472b6" : "#f59e0b", fontWeight: 700 }}>
                {score}
              </span>
            </>
          )}
          {anime.year && (
            <span style={{ fontSize: "10px", color: "#4a5568" }}>{anime.year}</span>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
};

// ─── GENERAL SHELF ───────────────────────────────────────────────────────────
interface ShelfProps {
  title: string;
  icon: string;
  items: Anime[];
  onAnimeClick: (anime: Anime) => void;
  onViewAll?: () => void;
  loading: boolean;
  badge?: string | null;
  accentColor?: string;
  ecchi?: boolean;
}

export const Shelf: React.FC<ShelfProps> = ({
  title,
  icon,
  items,
  onAnimeClick,
  onViewAll,
  loading,
  badge = null,
  ecchi = false,
}) => {
  const ref = useRef<HTMLDivElement>(null);
  const rootRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  const [shelfHov, setShelfHov] = useState(false);

  const scroll = (dir: number) => {
    ref.current?.scrollBy({ left: dir * 220, behavior: "smooth" });
  };

  useEffect(() => {
    const el = rootRef.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          setVisible(true);
          obs.disconnect();
        }
      },
      { threshold: 0.08 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  const titleColor = ecchi ? "#f472b6" : "#f1f5f9";

  return (
    <div
      ref={rootRef}
      onMouseEnter={() => setShelfHov(true)}
      onMouseLeave={() => setShelfHov(false)}
      style={{
        marginBottom: "34px",
        opacity: visible ? 1 : 0,
        transform: visible ? "none" : "translateY(18px)",
        transition: "opacity 0.55s ease, transform 0.55s cubic-bezier(0.34,1.2,0.64,1)",
        borderLeft: ecchi ? "3px solid rgba(244,114,182,0.4)" : "3px solid transparent",
        paddingLeft: ecchi ? "14px" : "0",
        borderRadius: ecchi ? "0 0 0 4px" : "0",
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          marginBottom: "14px",
        }}
      >
        <h2
          style={{
            fontSize: "17px",
            fontWeight: 800,
            color: titleColor,
            fontFamily: "'Rajdhani',sans-serif",
            letterSpacing: "0.4px",
            display: "flex",
            alignItems: "center",
            gap: "8px",
            transform: shelfHov ? "translateX(6px)" : "translateX(0)",
            transition: "transform 0.3s cubic-bezier(0.25, 1, 0.5, 1), color 0.3s",
          }}
        >
          <span style={{ display: "inline-block", animation: ecchi ? "iconSpin 6s ease-in-out infinite" : "none" }}>
            {icon}
          </span>
          {title}
          {ecchi && (
            <span
              style={{
                fontSize: "9px",
                fontWeight: 800,
                background: "linear-gradient(90deg,#ec4899,#f43f5e)",
                color: "#fff",
                padding: "2px 8px",
                borderRadius: "4px",
                letterSpacing: "1px",
                verticalAlign: "middle",
                animation: "rosePulse 3s ease-in-out infinite",
              }}
            >
              18+
            </span>
          )}
        </h2>
        <div style={{ display: "flex", gap: "10px", alignItems: "center" }}>
          {onViewAll && (
            <button
              onClick={onViewAll}
              style={{
                background: "none",
                border: "none",
                color: ecchi ? "#f472b6" : "#6366f1",
                fontSize: "12.5px",
                fontWeight: 700,
                cursor: "pointer",
                letterSpacing: "0.3px",
                transform: shelfHov ? "scale(1.05) translateX(-4px)" : "scale(1) translateX(0)",
                transition: "all 0.3s cubic-bezier(0.25, 1, 0.5, 1)",
              }}
            >
              View All →
            </button>
          )}
          <button
            onClick={() => scroll(-1)}
            style={{
              background: "#111120",
              border: "1px solid #1a1a2e",
              borderRadius: "6px",
              padding: "4px 7px",
              cursor: "pointer",
              color: "#64748b",
              display: "flex",
              alignItems: "center",
              transition: "background 0.15s",
            }}
          >
            <Icon name="chevronLeft" size={13} />
          </button>
          <button
            onClick={() => scroll(1)}
            style={{
              background: "#111120",
              border: "1px solid #1a1a2e",
              borderRadius: "6px",
              padding: "4px 7px",
              cursor: "pointer",
              color: "#64748b",
              display: "flex",
              alignItems: "center",
              transition: "background 0.15s",
            }}
          >
            <Icon name="chevronRight" size={13} />
          </button>
        </div>
      </div>
      <motion.div
        ref={ref}
        variants={{
          hidden: { opacity: 0 },
          visible: {
            opacity: 1,
            transition: {
              staggerChildren: 0.05,
            },
          },
        }}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: "-60px" }}
        style={{
          display: "flex",
          gap: "12px",
          overflowX: "auto",
          paddingBottom: "8px",
          scrollbarWidth: "none",
          scrollSnapType: "x mandatory",
          scrollBehavior: "smooth",
        }}
      >
        {loading
          ? Array(10)
              .fill(null)
              .map((_, i) => (
                <div key={i} style={{ width: "140px", flexShrink: 0, scrollSnapAlign: "start" }}>
                  <CardSkeleton />
                </div>
              ))
          : items.map((a, i) => (
              <motion.div
                key={`${a.mal_id || "item"}-${i}`}
                variants={{
                  hidden: { opacity: 0, y: 15, scale: 0.95 },
                  visible: {
                    opacity: 1,
                    y: 0,
                    scale: 1,
                    transition: {
                      type: "spring",
                      stiffness: 120,
                      damping: 14,
                    },
                  },
                }}
                style={{ width: "140px", flexShrink: 0, scrollSnapAlign: "start" }}
              >
                <AnimeCard
                  anime={a}
                  onClick={onAnimeClick}
                  badge={badge}
                  delay={-1}
                  epBadge={badge === "AIRING" ? (a.episodes ? `EP ${a.episodes}` : "AIRING") : null}
                  ecchi={ecchi}
                />
              </motion.div>
            ))}
      </motion.div>
    </div>
  );
};
