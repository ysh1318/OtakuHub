import { Anime } from "../types";

const JIKAN = "https://api.jikan.moe/v4";
export const delay = (ms: number) => new Promise(r => setTimeout(r, ms));

export async function jikanFetch(path: string, retries = 3): Promise<any> {
  for (let i = 0; i < retries; i++) {
    const backoff = 700 * Math.pow(2, i); // 700 → 1400 → 2800ms
    try {
      const res = await fetch(`${JIKAN}${path}`);
      if (res.status === 429) {
        await delay(backoff);
        continue;
      }
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.json();
    } catch (e) {
      if (i === retries - 1) throw e;
      await delay(backoff);
    }
  }
}

export const scoreColor = (s: number) => s >= 8.5 ? "#10b981" : s >= 7 ? "#f59e0b" : "#ef4444";

export const fmt = (n?: number) => {
  if (n == null) return "N/A";
  return n >= 1000000 
    ? `${(n / 1000000).toFixed(1)}M` 
    : n >= 1000 
      ? `${(n / 1000).toFixed(1)}K` 
      : n.toString();
};

export const WL_KEY = "otakuhub_watchlist_v2";
export const getWL = (): Anime[] => {
  try {
    return JSON.parse(localStorage.getItem(WL_KEY) || "[]");
  } catch {
    return [];
  }
};
export const saveWL = (v: Anime[]) => {
  try {
    localStorage.setItem(WL_KEY, JSON.stringify(v));
  } catch {}
};

export const EP_KEY = "otakuhub_ep_progress_v1";
export const getEpProgress = (): Record<number, number> => {
  try {
    return JSON.parse(localStorage.getItem(EP_KEY) || "{}");
  } catch {
    return {};
  }
};
export const saveEpProgress = (v: Record<number, number>) => {
  try {
    localStorage.setItem(EP_KEY, JSON.stringify(v));
  } catch {}
};
export const setEpWatched = (malId: number, ep: number) => {
  const p = getEpProgress();
  p[malId] = ep;
  saveEpProgress(p);
  window.dispatchEvent(new Event("ep_update"));
};
export const getEpWatched = (malId: number): number => getEpProgress()[malId] || 0;

export const ECCHI_AGE_KEY = "otakuhub_ecchi_age_verified_v1";
export const getAgeVerified = (): boolean => {
  try {
    return localStorage.getItem(ECCHI_AGE_KEY) === "yes";
  } catch {
    return false;
  }
};
export const setAgeVerified = () => {
  try {
    localStorage.setItem(ECCHI_AGE_KEY, "yes");
  } catch {}
};

export const HISTORY_KEY = "otakuhub_history_v1";
export const getHistory = (): Anime[] => {
  try {
    return JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]");
  } catch {
    return [];
  }
};
export const addToHistory = (anime: Anime) => {
  try {
    const h = getHistory();
    const next = [anime, ...h.filter(a => a.mal_id !== anime.mal_id)].slice(0, 50);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(next));
    window.dispatchEvent(new Event("history_update"));
  } catch {}
};
